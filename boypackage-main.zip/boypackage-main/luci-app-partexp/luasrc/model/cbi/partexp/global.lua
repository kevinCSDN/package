--[[
LuCI - Lua Configuration Interface
 Copyright (C) 2022  sirpdboy <herboy2008@gmail.com> https://github.com/sirpdboy/luci-app-partexp
]]--
local fs   = require "nixio.fs"
local util = require "nixio.util"
local tp   = require "luci.template.parser"
local uci=luci.model.uci.cursor()
  -- get all device names (sdX and mmcblkX)
  local target_devnames = {}
  for dev in fs.dir("/dev") do
    if dev:match("^sd[a-z]$")
      or dev:match("^mmcblk%d+$")
      or dev:match("^sata[a-z]$")
      or dev:match("^nvme%d+n%d+$")
      then
      table.insert(target_devnames, dev)
    end
  end
  local devices = {}
  for i, bname in pairs(target_devnames) do
    local device_info = {}
    local device = "/dev/" .. bname
    device_info["name"] = bname
    device_info["dev"] = device

    s = tonumber((fs.readfile("/sys/class/block/%s/size" % bname)))
    device_info["size"] = s and math.floor(s / 2048)

    devices[#devices+1] = device_info
end

local m,t,e
m = Map("partexp", "<font color='green'>" .. translate("One click partition expansion mounting tool") .."</font>",
translate( "Automatically format and mount the target device partition. If there are multiple partitions, it is recommended to manually delete all partitions before using this tool.<br/>For specific usage, see:") ..translate("<a href=\'https://github.com/sirpdboy/luci-app-partexp.git' target=\'_blank\'>GitHub @sirpdboy:luci-app-partexp</a>") )

t=m:section(TypedSection,"global")
t.anonymous=true

e=t:option(ListValue,"target_function", translate("Select function"),translate("Select the function to be performed"))
e:value("/overlay", translate("Expand application space overlay (/overlay)"))
-- e:value("/", translate("Use as root filesystem (/)"))
e:value("/opt", translate("Used as Docker data disk (/opt)"))
e:value("/dev", translate("Normal mount and use by device name(/dev/x1)"))

e=t:option(ListValue,"target_disk", translate("Destination hard disk"),translate("Select the hard disk device to operate"))
for i, d in ipairs(devices) do
	if d.name and d.size then
		e:value(d.name, "%s (%s, %d MB)" %{ d.name, d.dev, d.size })
	elseif d.name then
		e:value(d.name, "%s (%s)" %{ d.name, d.dev })
	end
end

o=t:option(Flag,"keep_config",translate("Keep configuration"),translate("Tick means to retain the settings"))
o:depends("target_function", "/overlay")
o.default=0

o=t:option(Flag,'auto_format', translate('Format before use'),translate("Ticking indicates formatting"))
o:depends("target_function", "/opt")
o:depends("target_function", "/dev")
o.default=0

o=t:option(DummyValue, '', '')
o.rawhtml = true
o.template ='partexp'


e=t:option(TextValue,"log")
e.rows=15
e.wrap="on"
e.readonly=true
e.cfgvalue=function(t,t)
return fs.readfile("/etc/partexp/partexp.log")or""
end
e.write=function(e,e,e)
end

-- e =t:option(DummyValue, '', '')
-- e.rawhtml = true
-- e.template = 'partexplog'

return m
